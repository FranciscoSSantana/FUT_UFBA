from tupy import *
from mainMenu import MainMenu

game: MainMenu = MainMenu()

run(globals())